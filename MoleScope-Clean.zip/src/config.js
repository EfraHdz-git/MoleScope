const config = {
    openaiApiKey: process.env.REACT_APP_OPENAI_API_KEY,
    huggingFaceApiKey: process.env.REACT_APP_HF_API_KEY,
    arEnabled: true,
    huggingFaceModel: 'mistralai/Mistral-7B-Instruct-v0.1',
    defaultMolecule: '/sample-molecules/caffeine.mol'
  };
  
  export default config;