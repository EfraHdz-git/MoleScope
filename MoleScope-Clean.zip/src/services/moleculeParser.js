import * as THREE from 'three';
import { atomColors } from '../utils/colorMap';

// Parse .mol file format
export const parseMolFile = (content) => {
  try {
    const lines = content.split('\n');
    
    // Get atom and bond counts from the counts line (4th line)
    // Format is AAABBBCCCDDDEEE where AAA = atom count
    const countLine = lines[3] || '';
    const atomCount = parseInt(countLine.substring(0, 3)) || 0;
    const bondCount = parseInt(countLine.substring(3, 6)) || 0;
    
    if (atomCount === 0) {
      console.error("No atoms found in file");
      return { atoms: [], bonds: [] };
    }
    
    const atoms = [];
    // Process atoms section (starts at line 4)
    for (let i = 0; i < atomCount && i + 4 < lines.length; i++) {
      const line = lines[4 + i] || '';
      if (line.length < 30) continue; // Skip malformed lines
      
      // Extract coordinates and element
      const x = parseFloat(line.substring(0, 10).trim()) || 0;
      const y = parseFloat(line.substring(10, 20).trim()) || 0;
      const z = parseFloat(line.substring(20, 30).trim()) || 0;
      const element = line.substring(31, 34).trim() || 'C'; // Default to carbon if no element
      
      atoms.push({
        position: new THREE.Vector3(x, y, z),
        element,
        radius: getAtomRadius(element)
      });
    }
    
    const bonds = [];
    // Process bonds section (starts after atoms)
    for (let i = 0; i < bondCount && i + 4 + atomCount < lines.length; i++) {
      const line = lines[4 + atomCount + i] || '';
      if (line.length < 9) continue; // Skip malformed lines
      
      // Extract bond information - atom indices (1-based) and bond order
      const atom1 = parseInt(line.substring(0, 3).trim()) - 1;
      const atom2 = parseInt(line.substring(3, 6).trim()) - 1;
      const bondOrder = parseInt(line.substring(6, 9).trim()) || 1;
      
      // Validate atom indices
      if (atom1 >= 0 && atom1 < atoms.length && 
          atom2 >= 0 && atom2 < atoms.length) {
        bonds.push({
          start: atom1,
          end: atom2,
          order: bondOrder
        });
      }
    }
    
    console.log(`Parsed ${atoms.length} atoms and ${bonds.length} bonds`);
    return { atoms, bonds };
  } catch (error) {
    console.error("Error parsing MOL file:", error);
    return { atoms: [], bonds: [] };
  }
};

// Helper functions for atom properties
function getAtomRadius(element) {
  const radiusMap = {
    'H': 0.3,
    'C': 0.7,
    'N': 0.65,
    'O': 0.6,
    'P': 1.0,
    'S': 1.0,
    // Add more elements as needed
  };
  return radiusMap[element] || 0.7; // Default radius if element not in map
}

// Similar function for PDB files
export const parsePdbFile = (content) => {
  try {
    const lines = content.split('\n');
    const atoms = [];
    
    // Process ATOM and HETATM records
    for (const line of lines) {
      if ((line.startsWith('ATOM') || line.startsWith('HETATM')) && line.length >= 54) {
        // Extract coordinates
        const x = parseFloat(line.substring(30, 38).trim()) || 0;
        const y = parseFloat(line.substring(38, 46).trim()) || 0;
        const z = parseFloat(line.substring(46, 54).trim()) || 0;
        
        // Extract element (columns 77-78 usually, but might be derived from atom name if missing)
        let element = line.length >= 78 ? line.substring(76, 78).trim() : '';
        if (!element) {
          // Try to derive from atom name
          element = line.substring(12, 14).trim().replace(/[0-9]/g, '');
        }
        element = element || 'C'; // Default to carbon
        
        atoms.push({
          position: new THREE.Vector3(x, y, z),
          element,
          radius: getAtomRadius(element)
        });
      }
    }
    
    // Simple proximity-based bond generation
    const bonds = [];
    const bondDistanceThreshold = 2.0; // Ångströms
    
    for (let i = 0; i < atoms.length; i++) {
      for (let j = i + 1; j < atoms.length; j++) {
        const distance = atoms[i].position.distanceTo(atoms[j].position);
        if (distance < bondDistanceThreshold) {
          bonds.push({
            start: i,
            end: j,
            order: 1 // Default single bond
          });
        }
      }
    }
    
    console.log(`Parsed ${atoms.length} atoms and ${bonds.length} bonds from PDB`);
    return { atoms, bonds };
  } catch (error) {
    console.error("Error parsing PDB file:", error);
    return { atoms: [], bonds: [] };
  }
};

export const getFileFormat = (filename) => {
  const extension = filename.split('.').pop().toLowerCase();
  return extension;
};

export const parseMoleculeFile = (content, fileFormat) => {
  if (fileFormat === 'mol' || fileFormat === 'sdf') {
    return parseMolFile(content);
  } else if (fileFormat === 'pdb') {
    return parsePdbFile(content);
  }
  throw new Error(`Unsupported file format: ${fileFormat}`);
};