// src/services/pubchemService.js
const PUBCHEM_API_BASE = 'https://pubchem.ncbi.nlm.nih.gov/rest/pug';

export const fetchMoleculeByName = async (name) => {
  try {
    // Fetch the compound ID from the name
    const response = await fetch(`${PUBCHEM_API_BASE}/compound/name/${encodeURIComponent(name)}/cids/JSON`);
    if (!response.ok) throw new Error('Compound not found');
    
    const data = await response.json();
    if (!data.IdentifierList || !data.IdentifierList.CID || data.IdentifierList.CID.length === 0) {
      throw new Error('No CID found for this compound');
    }
    
    const cid = data.IdentifierList.CID[0];
    console.log(`🔍 Found CID: ${cid} for compound: ${name}`);
    
    // Get the MOL file for this CID
    const molResponse = await fetch(`${PUBCHEM_API_BASE}/compound/cid/${cid}/record/SDF/?record_type=3d`);
    if (!molResponse.ok) {
      // Try 2D if 3D is not available
      const mol2dResponse = await fetch(`${PUBCHEM_API_BASE}/compound/cid/${cid}/record/SDF/?record_type=2d`);
      if (!mol2dResponse.ok) throw new Error('Failed to retrieve molecule data');
      return { content: await mol2dResponse.text(), format: 'sdf', name: name, cid: cid };
    }
    
    return { content: await molResponse.text(), format: 'sdf', name: name, cid: cid };
  } catch (error) {
    console.error('Error fetching from PubChem:', error);
    throw error;
  }
};

export const fetchMoleculeByCID = async (cid) => {
  try {
    // Get compound name
    const nameResponse = await fetch(`${PUBCHEM_API_BASE}/compound/cid/${cid}/property/Title/JSON`);
    if (!nameResponse.ok) throw new Error('Failed to get compound name');
    const nameData = await nameResponse.json();
    const name = nameData.PropertyTable?.Properties?.[0]?.Title || `Compound ${cid}`;
    
    // Get the MOL file
    const molResponse = await fetch(`${PUBCHEM_API_BASE}/compound/cid/${cid}/record/SDF/?record_type=3d`);
    if (!molResponse.ok) {
      // Try 2D if 3D is not available
      const mol2dResponse = await fetch(`${PUBCHEM_API_BASE}/compound/cid/${cid}/record/SDF/?record_type=2d`);
      if (!mol2dResponse.ok) throw new Error('Failed to retrieve molecule data');
      return { content: await mol2dResponse.text(), format: 'sdf', name: name, cid: cid };
    }
    
    return { content: await molResponse.text(), format: 'sdf', name: name, cid: cid };
  } catch (error) {
    console.error('Error fetching from PubChem:', error);
    throw error;
  }
};