// src/services/pubchemInfoService.js
const PUBCHEM_API_BASE = 'https://pubchem.ncbi.nlm.nih.gov/rest/pug';

export const fetchMoleculeInfo = async (cid) => {
  try {
    // Fetch molecule properties
    const propertiesResponse = await fetch(
      `${PUBCHEM_API_BASE}/compound/cid/${cid}/property/MolecularFormula,MolecularWeight,CanonicalSMILES,InChI,InChIKey,IUPACName,XLogP,ExactMass/JSON`
    );
    
    if (!propertiesResponse.ok) throw new Error('Failed to fetch molecule properties');
    const propertiesData = await propertiesResponse.json();
    
    // Get the compound data
    const properties = propertiesData.PropertyTable.Properties[0] || {};
    
    // Fetch compound synonyms (common names)
    const synonymsResponse = await fetch(
      `${PUBCHEM_API_BASE}/compound/cid/${cid}/synonyms/JSON`
    );
    
    let synonyms = [];
    if (synonymsResponse.ok) {
      const synonymsData = await synonymsResponse.json();
      synonyms = synonymsData.InformationList?.Information?.[0]?.Synonym || [];
      // Limit to 5 common names
      synonyms = synonyms.slice(0, 5);
    }
    
    return {
      cid,
      formula: properties.MolecularFormula,
      weight: properties.MolecularWeight,
      smiles: properties.CanonicalSMILES,
      inchi: properties.InChI,
      inchiKey: properties.InChIKey,
      iupacName: properties.IUPACName,
      logP: properties.XLogP,
      exactMass: properties.ExactMass,
      commonNames: synonyms,
    };
  } catch (error) {
    console.error('Error fetching molecule info:', error);
    return null;
  }
};