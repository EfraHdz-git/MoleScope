import axios from 'axios';
import config from '../config';

const apiKey = config.openaiApiKey;

export const generateMoleculeExplanation = async (moleculeName, moleculeData) => {
  try {
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-4-turbo',
        messages: [
          {
            role: 'system',
            content: 'You are a helpful chemistry expert. Provide concise, engaging explanations about molecules.'
          },
          {
            role: 'user',
            content: `Explain this molecule in simple terms: ${moleculeName}. Include its structure, function, and interesting facts. Keep it under 150 words.`
          }
        ],
        max_tokens: 300
      },
      {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        }
      }
    );
    
    return response.data.choices[0].message.content;
  } catch (error) {
    console.error('Error calling OpenAI API:', error);
    return 'Unable to generate explanation at this time.';
  }
};