import axios from 'axios';
import config from '../config';
import { generateMoleculeExplanation as fallbackOpenAI } from './openaiService'; // fallback imported

const hfApiKey = config.huggingFaceApiKey;
const model = 'mistralai/Mistral-7B-Instruct-v0.1';

export const generateMoleculeExplanation = async (moleculeName) => {
  const prompt = `Explain what "${moleculeName}" is in less than 150 words.
Include its structure, function in biology or medicine, and one interesting fact.
Explain it in simple terms so that someone without a chemistry background can understand.`;

  console.log('🧪 Final Prompt Sent:', prompt);

  try {
    const response = await axios.post(
      `https://api-inference.huggingface.co/models/${model}`,
      {
        inputs: prompt,
        parameters: {
          max_new_tokens: 250,
          temperature: 0.7,
        },
      },
      {
        headers: {
          Authorization: `Bearer ${hfApiKey}`,
          'Content-Type': 'application/json',
        },
      }
    );

    const result = response.data;
    const output = result[0]?.generated_text || '';
    console.log('✅ Hugging Face response:', output);

    return output.replace(prompt, '').trim();
  } catch (error) {
    console.warn('⚠️ Hugging Face failed — using OpenAI fallback.');
    return fallbackOpenAI(moleculeName); // gracefully fallback
  }
};
