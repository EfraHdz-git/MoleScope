// src/utils/colorMap.js
// Convert hex color to THREE.js color integer
const hexToInt = (hex) => parseInt(hex.replace('#', '0x'));

// CPK (traditional) coloring scheme
const cpkColors = {
  H: '#FFFFFF', // White
  C: '#909090', // Light grey
  N: '#3050F8', // Blue
  O: '#FF0D0D', // Red
  F: '#90E050', // Light green
  CL: '#1FF01F', // Green
  BR: '#A62929', // Brown
  I: '#940094', // Dark purple
  HE: '#D9FFFF', // Light cyan
  NE: '#B3E3F5', // Cyan
  AR: '#80D1E3', // Light blue
  XE: '#940094', // Purple
  KR: '#5CB8D1', // Light blue
  P: '#FF8000', // Orange
  S: '#FFFF30', // Yellow
  B: '#FFB5B5', // Pink
  LI: '#CC80FF', // Lavender
  NA: '#AB5CF2', // Purple
  K: '#8F40D4', // Purple
  MG: '#8AFF00', // Light green
  CA: '#3DFF00', // Green
  TI: '#BFC2C7', // Silver
  FE: '#E06633', // Orange
  ZN: '#7D80B0', // Grey-blue
  // Add more elements as needed
};

// Jmol coloring scheme
const jmolColors = {
  H: '#FFFFFF', // White
  C: '#909090', // Grey
  N: '#3050F8', // Blue
  O: '#FF0D0D', // Red
  F: '#90E050', // Light green
  CL: '#1FF01F', // Green
  BR: '#A62929', // Brown
  I: '#940094', // Dark purple
  P: '#FF8000', // Orange
  S: '#FFFF30', // Yellow
  // The rest are similar to CPK
};

// Rasmol coloring scheme
const rasmolColors = {
  H: '#FFFFFF', // White
  C: '#C8C8C8', // Light grey
  N: '#8F8FFF', // Light blue
  O: '#F00000', // Red
  F: '#C8FF00', // Yellow-green
  CL: '#00C800', // Green
  BR: '#C80000', // Red
  I: '#940094', // Purple
  P: '#FFC800', // Orange
  S: '#FFC832', // Yellow
  // More elements
};

// Element-based coloring (periodic table groups)
const elementColors = {
  // Alkali metals
  LI: '#FF69B4', // Pink
  NA: '#FF69B4',
  K: '#FF69B4',
  RB: '#FF69B4',
  CS: '#FF69B4',
  FR: '#FF69B4',
  
  // Alkaline earth metals
  BE: '#FFD700', // Gold
  MG: '#FFD700',
  CA: '#FFD700',
  SR: '#FFD700',
  BA: '#FFD700',
  RA: '#FFD700',
  
  // Transition metals
  SC: '#909090', // Grey
  TI: '#909090',
  V: '#909090',
  CR: '#909090',
  MN: '#909090',
  FE: '#909090',
  CO: '#909090',
  NI: '#909090',
  CU: '#DAA520', // Golden color for Copper
  ZN: '#909090',
  
  // Main group elements
  B: '#00FF00', // Green
  C: '#000000', // Black
  N: '#0000FF', // Blue
  O: '#FF0000', // Red
  F: '#7CFC00', // Lawn green
  NE: '#B3E3F5', // Cyan
  
  // More main group elements
  AL: '#BFC2C7', // Silver
  SI: '#DAA520', // Golden
  P: '#FFA500', // Orange
  S: '#FFFF00', // Yellow
  CL: '#00FF00', // Green
  AR: '#B3E3F5', // Cyan
  
  // Default
  H: '#FFFFFF', // White
};

// Available color schemes
const colorSchemes = {
  cpk: cpkColors,
  jmol: jmolColors,
  rasmol: rasmolColors,
  element: elementColors,
};

// Default color for unknown elements
const defaultColor = '#A9A9A9'; // Dark grey

// Function to get atom color by element and scheme
export const getAtomColor = (element, scheme = 'cpk') => {
  // Make element uppercase for consistent lookup
  const upperElement = element ? element.toUpperCase() : '';
  
  // Get the color scheme
  const selectedScheme = colorSchemes[scheme] || colorSchemes.cpk;
  
  // Return color as integer for THREE.js
  return hexToInt(selectedScheme[upperElement] || defaultColor);
};

// Export color schemes for the selector
export const availableColorSchemes = [
  { id: 'cpk', name: 'CPK (Classic)' },
  { id: 'jmol', name: 'JMol' },
  { id: 'rasmol', name: 'RasMol' },
  { id: 'element', name: 'Periodic Groups' },
];

// Export atom colors for reference
export const atomColors = cpkColors;