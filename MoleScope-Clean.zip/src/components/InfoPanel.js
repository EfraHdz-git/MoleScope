import React from 'react';
import '../styles/main.css';

const InfoPanel = () => (
  <div className="info-panel-content">
    {/* Added info-panel-title class for mobile spacing */}
    <h3 className="mb-4 info-panel-title">MoleScope AR</h3>

    <div className="info-section">
      <h5>🔍 Problem</h5>
      <p>
        Traditional molecule visualization has limitations:
      </p>
      <ul>
        <li>2D diagrams lack depth and perspective</li>
        <li>Few interactive options for education and research</li>
        <li>Limited accessibility to AR visualization tools</li>
      </ul>
    </div>

    <div className="info-section">
      <h5>💡 Solution</h5>
      <p>
        A browser-based 3D and AR molecule viewer that:
      </p>
      <ul>
        <li>Renders <code>.mol</code> and <code>.pdb</code> files in 3D</li>
        <li>Shows molecules in AR with marker tracking</li>
        <li>Provides AI-powered molecular explanations</li>
        <li>Works via drag-and-drop or URL sharing</li>
      </ul>
    </div>

    <div className="info-section">
      <h5>📊 Benefits</h5>
      <ul>
        <li>Makes molecules interactive for education</li>
        <li>Enhances presentations and demos</li>
        <li>Works on any device with a browser</li>
        <li>No special hardware or software needed</li>
      </ul>
    </div>

    <div className="info-section">
      <h5>🎯 Who It's For</h5>
      <span className="badge bg-light text-dark mb-2">Researchers</span>
      <span className="badge bg-light text-dark mb-2">Educators</span>
      <span className="badge bg-light text-dark mb-2">Students</span>
      <span className="badge bg-light text-dark mb-2">Pharma Teams</span>
      <span className="badge bg-light text-dark mb-2">STEM Events</span>
    </div>
  </div>
);

export default InfoPanel;