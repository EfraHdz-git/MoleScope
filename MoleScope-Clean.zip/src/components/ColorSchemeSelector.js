// src/components/ColorSchemeSelector.js
import React from 'react';
import { availableColorSchemes } from '../utils/colorMap';
import '../styles/ColorSchemeSelector.css';

const ColorSchemeSelector = ({ currentScheme, onSchemeChange }) => {
  return (
    <div className="color-scheme-selector">
      <span className="selector-icon">🎨</span>
      <select 
        id="color-scheme"
        value={currentScheme}
        onChange={(e) => onSchemeChange(e.target.value)}
        className="scheme-dropdown"
      >
        {availableColorSchemes.map(scheme => (
          <option key={scheme.id} value={scheme.id}>
            {scheme.name}
          </option>
        ))}
      </select>
    </div>
  );
};

export default ColorSchemeSelector;