import React, { useState, useEffect } from 'react';

// Before:
// import { generateMoleculeExplanation } from '../services/openaiService';
// After:
import { generateMoleculeExplanation } from '../services/huggingFaceService';


const AIExplanation = ({ moleculeName, moleculeData, isLoading }) => {
  const [explanation, setExplanation] = useState('');
  const [loading, setLoading] = useState(false);
  
  useEffect(() => {
    if (moleculeName && moleculeData && !isLoading) {
      setLoading(true);
      generateMoleculeExplanation(moleculeName, moleculeData)
        .then(explanation => {
          setExplanation(explanation);
          setLoading(false);
        })
        .catch(error => {
          console.error('Error getting explanation:', error);
          setExplanation('Failed to generate explanation. Please try again.');
          setLoading(false);
        });
    }
  }, [moleculeName, moleculeData, isLoading]);
  
  return (
    <div className="ai-explanation">
      <h3>AI Explanation</h3>
      {loading ? (
        <div className="loading-spinner">Loading explanation...</div>
      ) : explanation ? (
        <div className="explanation-content">
          <p>{explanation}</p>
          <div className="powered-by">
            <small>Powered by OpenSource Models</small>
          </div>
        </div>
      ) : (
        <p>Upload a molecule to see an AI-generated explanation.</p>
      )}
    </div>
  );
};

export default AIExplanation;