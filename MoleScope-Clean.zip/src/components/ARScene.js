import React, { useEffect, useRef } from 'react';
import { getAtomColor } from '../utils/colorMap';

const ARScene = ({ moleculeData, enabled, onExitAR, colorScheme = 'cpk', moleculeName }) => {
  const containerRef = useRef(null);
  
  useEffect(() => {
    // Only proceed if we have data and AR is enabled
    if (!moleculeData || !enabled || !containerRef.current) return;
    
    console.log("Setting up AR scene with molecule data");
    
    // Clear any previous content
    containerRef.current.innerHTML = '';
    
    // Hide all other UI elements when AR is active
    document.body.classList.add('ar-mode');
    
    // Create fullscreen container
    const arContainer = document.createElement('div');
    arContainer.style.position = 'fixed';
    arContainer.style.top = '0';
    arContainer.style.left = '0';
    arContainer.style.width = '100vw';
    arContainer.style.height = '100vh';
    arContainer.style.zIndex = '9999';
    document.body.appendChild(arContainer);
    
    // Tracking mode state
    let smoothingEnabled = true; // Default to smoothing
    
    // Position smoothing state - defined at this scope level so it's accessible everywhere
    const positionHistory = []; 
    
    // Dynamically load A-Frame scripts if needed
    const aframeScript = document.createElement('script');
    aframeScript.src = 'https://aframe.io/releases/1.2.0/aframe.min.js';
    aframeScript.async = true;
    
    const arjsScript = document.createElement('script');
    arjsScript.src = 'https://raw.githack.com/AR-js-org/AR.js/3.3.1/aframe/build/aframe-ar.js';
    arjsScript.async = true;
    
    // Add HandTracking.js script
    const handTrackingScript = document.createElement('script');
    handTrackingScript.src = 'https://cdn.jsdelivr.net/npm/handtrackjs/dist/handtrack.min.js';
    handTrackingScript.async = true;
    
    // Check if scripts are already loaded
    if (!document.querySelector('script[src*="aframe.min.js"]')) {
      document.head.appendChild(aframeScript);
    }
    
    if (!document.querySelector('script[src*="aframe-ar.js"]')) {
      document.head.appendChild(arjsScript);
    }
    
    if (!document.querySelector('script[src*="handtrack.min.js"]')) {
      document.head.appendChild(handTrackingScript);
    }
    
    // Wait for scripts to load
    const setupAR = () => {
      // Create A-Frame scene
      const sceneEl = document.createElement('a-scene');
      sceneEl.setAttribute('embedded', '');
      sceneEl.setAttribute('arjs', 'sourceType: webcam; debugUIEnabled: false; detectionMode: mono_and_matrix; matrixCodeType: 3x3;');
      
      // Create marker with improved detection settings
      const hiroMarker = document.createElement('a-marker');
      hiroMarker.setAttribute('preset', 'hiro');
      hiroMarker.setAttribute('id', 'hiro-marker');
      hiroMarker.setAttribute('smooth', 'true');
      hiroMarker.setAttribute('smoothCount', '10');
      hiroMarker.setAttribute('smoothTolerance', '0.05');
      hiroMarker.setAttribute('smoothThreshold', '2');
      
      // Initialize marker visibility tracking
      let markerVisible = false;
      let markerLostTime = 0;
      const MARKER_PERSISTENCE_TIME = 500; // Keep visible for 500ms after losing sight
      
      hiroMarker.addEventListener('markerFound', () => {
        console.log("Hiro marker found!");
        markerVisible = true;
        if (hiroMoleculeEntity) {
          hiroMoleculeEntity.setAttribute('visible', 'true');
        }
        if (hiroTextContainer) {
          hiroTextContainer.setAttribute('visible', 'true');
        }
      });
      
      hiroMarker.addEventListener('markerLost', () => {
        console.log("Hiro marker lost!");
        markerVisible = false;
        markerLostTime = Date.now();
        
        // If smoothing is disabled, hide immediately
        if (!smoothingEnabled) {
          if (hiroMoleculeEntity) {
            hiroMoleculeEntity.setAttribute('visible', 'false');
          }
          if (hiroTextContainer) {
            hiroTextContainer.setAttribute('visible', 'false');
          }
        }
        // Otherwise, we'll let the animation loop handle hiding after persistence time
      });
      
      // Create a hand marker entity
      const handMarker = document.createElement('a-entity');
      handMarker.setAttribute('id', 'hand-marker');
      handMarker.setAttribute('visible', 'false');
      
      // Create non-rotating containers for text
      const hiroTextContainer = document.createElement('a-entity');
      hiroTextContainer.setAttribute('position', '0 1.2 0'); // Position above the molecule
      hiroMarker.appendChild(hiroTextContainer);
      
      const handTextContainer = document.createElement('a-entity');
      handTextContainer.setAttribute('position', '0 0.4 0'); // Position above the hand molecule
      handMarker.appendChild(handTextContainer);
      
      // Create rotating containers for molecules only
      const hiroRotatingContainer = document.createElement('a-entity');
      hiroRotatingContainer.setAttribute('position', '0 0.25 0');
      hiroRotatingContainer.setAttribute('animation', 'property: rotation; to: 0 360 0; loop: true; dur: 20000; easing: linear');
      hiroMarker.appendChild(hiroRotatingContainer);
      
      const handRotatingContainer = document.createElement('a-entity');
      handRotatingContainer.setAttribute('position', '0 0.15 0'); // Lower position for hand marker
      handRotatingContainer.setAttribute('animation', 'property: rotation; to: 0 360 0; loop: true; dur: 20000; easing: linear');
      handMarker.appendChild(handRotatingContainer);
      
      // Create parent entities for molecules
      const hiroMoleculeEntity = document.createElement('a-entity');
      hiroMoleculeEntity.setAttribute('scale', '0.05 0.05 0.05');
      hiroRotatingContainer.appendChild(hiroMoleculeEntity);
      
      const handMoleculeEntity = document.createElement('a-entity');
      handMoleculeEntity.setAttribute('scale', '0.015 0.015 0.015'); // 25% smaller for hand marker
      handRotatingContainer.appendChild(handMoleculeEntity);
      
      // Use the moleculeName prop directly
      const displayName = moleculeName || 'Molecule'; 
      console.log("Using molecule name in AR:", displayName);
      
      // Create and add molecule labels and structures to both markers
      const createMoleculeRepresentation = (parentEntity, rotatingContainer, textContainer, isHandMarker = false) => {
        // Add molecule label to the non-rotating text container
        const text = document.createElement('a-text');
        text.setAttribute('value', displayName);
        text.setAttribute('position', '0 0 0'); 
        text.setAttribute('rotation', '0 0 0'); 
        text.setAttribute('align', 'center');
        text.setAttribute('color', '#FFFF00');
        text.setAttribute('scale', isHandMarker ? '0.8 0.8 0.8' : '1.5 1.5 1.5');
        text.setAttribute('width', '3');
        textContainer.appendChild(text);
        
        // Add atoms to the rotating container
        moleculeData.atoms.forEach((atom) => {
          if (!atom || !atom.position) {
            return;
          }
          
          const sphere = document.createElement('a-sphere');
          sphere.setAttribute('position', `${atom.position.x} ${atom.position.y} ${atom.position.z}`);
          sphere.setAttribute('radius', atom.radius || 0.2);
          
          // Convert THREE.js color to hex string for A-Frame
          const colorHex = `#${getAtomColor(atom.element, colorScheme).toString(16).padStart(6, '0')}`;
          sphere.setAttribute('color', colorHex);
          
          // Improved material properties
          sphere.setAttribute('shader', 'standard');
          sphere.setAttribute('metalness', '0.2');
          sphere.setAttribute('roughness', '0.3');
          sphere.setAttribute('opacity', '0.95');
          
          parentEntity.appendChild(sphere);
        });
        
        // Add bonds
        moleculeData.bonds.forEach((bond) => {
          const startAtom = moleculeData.atoms[bond.start];
          const endAtom = moleculeData.atoms[bond.end];
          
          if (!startAtom || !endAtom || !startAtom.position || !endAtom.position) {
            return;
          }
          
          const start = startAtom.position;
          const end = endAtom.position;
          
          // Calculate midpoint and direction
          const midX = (start.x + end.x) / 2;
          const midY = (start.y + end.y) / 2;
          const midZ = (start.z + end.z) / 2;
          
          // Calculate height (distance)
          const deltaX = end.x - start.x;
          const deltaY = end.y - start.y;
          const deltaZ = end.z - start.z;
          const height = Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
          
          // Create cylinder for bond
          const cylinder = document.createElement('a-cylinder');
          cylinder.setAttribute('position', `${midX} ${midY} ${midZ}`);
          cylinder.setAttribute('height', height);
          cylinder.setAttribute('radius', '0.07');
          cylinder.setAttribute('color', '#cccccc');
          
          // Calculate rotation to point cylinder in right direction
          const direction = { x: deltaX, y: deltaY, z: deltaZ };
          const phi = Math.atan2(direction.z, direction.x);
          const theta = Math.acos(direction.y / height);
          
          cylinder.setAttribute('rotation', `${(90 - theta * 180 / Math.PI)} ${phi * 180 / Math.PI} 0`);
          
          parentEntity.appendChild(cylinder);
        });
      };
      
      // Create molecule representations for both markers
      createMoleculeRepresentation(hiroMoleculeEntity, hiroRotatingContainer, hiroTextContainer, false);
      createMoleculeRepresentation(handMoleculeEntity, handRotatingContainer, handTextContainer, true);
      
      // Add lighting to markers (no floor plane for hand marker)
      const addLighting = (marker, includeFloor = true) => {
        const ambientLight = document.createElement('a-light');
        ambientLight.setAttribute('type', 'ambient');
        ambientLight.setAttribute('color', '#ffffff');
        ambientLight.setAttribute('intensity', '0.7');
        marker.appendChild(ambientLight);
        
        const directionalLight = document.createElement('a-light');
        directionalLight.setAttribute('type', 'directional');
        directionalLight.setAttribute('color', '#ffffff');
        directionalLight.setAttribute('intensity', '0.7');
        directionalLight.setAttribute('position', '1 1 1');
        marker.appendChild(directionalLight);
        
        const spotLight = document.createElement('a-light');
        spotLight.setAttribute('type', 'spot');
        spotLight.setAttribute('color', '#aaaaff');
        spotLight.setAttribute('position', '-1 2 1');
        spotLight.setAttribute('intensity', '0.5');
        marker.appendChild(spotLight);
        
        // Only add floor plane if requested (for Hiro marker but not hand)
        if (includeFloor) {
          const plane = document.createElement('a-plane');
          plane.setAttribute('position', '0 0 0');
          plane.setAttribute('rotation', '-90 0 0');
          plane.setAttribute('width', '1.2');
          plane.setAttribute('height', '1.2');
          plane.setAttribute('color', '#222');
          plane.setAttribute('opacity', '0.6');
          marker.appendChild(plane);
        }
      };
      
      addLighting(hiroMarker, true); // Include floor for Hiro marker
      addLighting(handMarker, false); // No floor for hand marker
      
      // Add camera
      const camera = document.createElement('a-entity');
      camera.setAttribute('camera', '');
      camera.setAttribute('id', 'a-camera');
      
      // Create exit button
      const exitButton = document.createElement('button');
      exitButton.innerText = 'Exit AR';
      exitButton.style.position = 'fixed';
      exitButton.style.bottom = '20px';
      exitButton.style.left = '50%';
      exitButton.style.transform = 'translateX(-50%)';
      exitButton.style.zIndex = '10000';
      exitButton.style.padding = '10px 20px';
      exitButton.style.backgroundColor = '#3498db';
      exitButton.style.color = 'white';
      exitButton.style.border = 'none';
      exitButton.style.borderRadius = '5px';
      exitButton.style.cursor = 'pointer';
      
      exitButton.addEventListener('click', () => {
        // Stop hand tracking
        if (window.handTrackingModel) {
          window.handTrackingModel.dispose();
          window.handTrackingModel = null;
        }
        
        // Get all video elements that might have been created by AR.js
        const videoElements = document.querySelectorAll('video');
        
        // Stop all video streams
        videoElements.forEach(video => {
          if (video.srcObject) {
            const tracks = video.srcObject.getTracks();
            tracks.forEach(track => {
              track.stop(); // This properly stops the camera
            });
            video.srcObject = null;
          }
        });
        
        // Clean up AR view
        if (arContainer) {
          document.body.removeChild(arContainer);
        }
        document.body.removeChild(exitButton);
        if (smoothingToggle) {
          document.body.removeChild(smoothingToggle);
        }
        document.body.classList.remove('ar-mode');
        
        // Notify parent component
        if (onExitAR) {
          onExitAR();
        }
      });
      
      document.body.appendChild(exitButton);
      
      // Create smoothing toggle (moved to top left)
      const smoothingToggle = document.createElement('div');
      smoothingToggle.style.position = 'fixed';
      smoothingToggle.style.top = '20px';
      smoothingToggle.style.left = '20px';
      smoothingToggle.style.zIndex = '10000';
      smoothingToggle.style.backgroundColor = 'rgba(0,0,0,0.7)';
      smoothingToggle.style.padding = '10px';
      smoothingToggle.style.borderRadius = '5px';
      smoothingToggle.style.color = 'white';
      smoothingToggle.style.display = 'flex';
      smoothingToggle.style.alignItems = 'center';
      smoothingToggle.style.gap = '10px';
      
      smoothingToggle.innerHTML = `
        <label for="smoothing-toggle" style="margin: 0; font-size: 14px;">Smooth Tracking:</label>
        <label class="switch" style="position: relative; display: inline-block; width: 40px; height: 20px;">
          <input type="checkbox" id="smoothing-toggle" checked style="opacity: 0; width: 0; height: 0;">
          <span style="position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 10px;"></span>
        </label>
      `;
      
      document.body.appendChild(smoothingToggle);
      
      // Style the toggle switch
      const toggleSpan = smoothingToggle.querySelector('span');
      toggleSpan.style.backgroundColor = '#2196F3';
      
      // Add toggle functionality
      const toggleInput = smoothingToggle.querySelector('input');
      toggleInput.addEventListener('change', () => {
        smoothingEnabled = toggleInput.checked;
        
        // Update the toggle appearance
        toggleSpan.style.backgroundColor = smoothingEnabled ? '#2196F3' : '#ccc';
        
        // Reset position history when switching modes
        positionHistory.length = 0;
      });
      
      // Assemble scene
      sceneEl.appendChild(hiroMarker);
      sceneEl.appendChild(handMarker);
      sceneEl.appendChild(camera);
      
      // Append to container
      arContainer.appendChild(sceneEl);
      
      // Set up animation loop for persistent visibility
      const checkMarkerPersistence = () => {
        if (smoothingEnabled && !markerVisible && Date.now() - markerLostTime > MARKER_PERSISTENCE_TIME) {
          // Only hide after persistence time has elapsed
          if (hiroMoleculeEntity) {
            hiroMoleculeEntity.setAttribute('visible', 'false');
          }
          if (hiroTextContainer) {
            hiroTextContainer.setAttribute('visible', 'false');
          }
        }
        
        requestAnimationFrame(checkMarkerPersistence);
      };
      
      checkMarkerPersistence();
      
      // Set up hand tracking with smoothing
      const setupHandTracking = () => {
        if (!window.handTrack) {
          console.error("HandTrack.js library not loaded");
          return;
        }
        
        // Add a canvas for hand tracking
        const handTrackingCanvas = document.createElement('canvas');
        handTrackingCanvas.width = 640;
        handTrackingCanvas.height = 480;
        handTrackingCanvas.style.display = 'none';
        arContainer.appendChild(handTrackingCanvas);
        
        // Model parameters - increased threshold for more reliable detection
        const modelParams = {
          flipHorizontal: true,
          maxNumBoxes: 1, // We only care about one hand
          iouThreshold: 0.5,
          scoreThreshold: 0.75 // Higher for more stability
        };
        
        // Hand tracking state
        let handVisible = false;
        let handLostTime = 0;
        const HAND_PERSISTENCE_TIME = 300; // ms to keep hand visible after losing tracking
        const MAX_HISTORY = 10; // Number of frames to average
        
        // Load the model
        window.handTrack.load(modelParams).then(model => {
          window.handTrackingModel = model;
          console.log("Hand tracking model loaded!");
          
          // Get video element created by AR.js
          const arVideo = document.querySelector('video');
          
          if (!arVideo) {
            console.error("AR.js video element not found");
            return;
          }
          
          // Function to detect hands and update the marker position
          const runDetection = () => {
            if (!window.handTrackingModel || !arVideo || !handMarker) {
              return;
            }
            
            const ctx = handTrackingCanvas.getContext('2d');
            ctx.drawImage(arVideo, 0, 0, handTrackingCanvas.width, handTrackingCanvas.height);
            
            window.handTrackingModel.detect(handTrackingCanvas).then(predictions => {
              // Found a hand
              if (predictions.length > 0) {
                const palm = predictions[0];
                
                // Make sure we detected a palm
                if (palm.label === 'open' || palm.label === 'point' || palm.label === 'palm') {
                  handVisible = true;
                  
                  // Calculate normalized position (0-1) within the video frame
                  const videoWidth = arVideo.videoWidth || 640;
                  const videoHeight = arVideo.videoHeight || 480;
                  
                  const centerX = palm.bbox[0] + palm.bbox[2]/2;
                  const centerY = palm.bbox[1] + palm.bbox[3]/2;
                  
                  // Convert to normalized coordinates (0-1)
                  const normalizedX = centerX / videoWidth;
                  const normalizedY = centerY / videoHeight;
                  
                  // Convert to A-Frame's coordinate system (-1.5 to 1.5 assuming default FOV)
                  const aframeX = (normalizedX - 0.5) * 3;
                  const aframeY = (0.5 - normalizedY) * 3; // Invert Y-axis
                  
                  // Use palm size for Z distance calculation
                  const palmSize = Math.max(palm.bbox[2], palm.bbox[3]);
                  const normalizedSize = palmSize / Math.max(videoWidth, videoHeight);
                  const aframeZ = -1.5 + normalizedSize * 3; // Further = more negative
                  
                  if (smoothingEnabled) {
                    // Add to position history for smoothing
                    positionHistory.push({ x: aframeX, y: aframeY, z: aframeZ });
                    
                    // Keep history at max length
                    if (positionHistory.length > MAX_HISTORY) {
                      positionHistory.shift();
                    }
                    
                    // Calculate smoothed position (average of last N positions)
                    let smoothX = 0, smoothY = 0, smoothZ = 0;
                    for (const pos of positionHistory) {
                      smoothX += pos.x;
                      smoothY += pos.y;
                      smoothZ += pos.z;
                    }
                    smoothX /= positionHistory.length;
                    smoothY /= positionHistory.length;
                    smoothZ /= positionHistory.length;
                    
                    // Update hand marker position with smoothed values
                    handMarker.setAttribute('position', `${smoothX} ${smoothY} ${smoothZ}`);
                  } else {
                    // Immediate tracking - no smoothing
                    handMarker.setAttribute('position', `${aframeX} ${aframeY} ${aframeZ}`);
                  }
                  
                  handMarker.setAttribute('visible', 'true');
                  handMoleculeEntity.setAttribute('visible', 'true');
                  handTextContainer.setAttribute('visible', 'true');
                } else {
                  // Not a palm
                  handVisible = false;
                  handLostTime = Date.now();
                  
                  // If smoothing is disabled, hide immediately
                  if (!smoothingEnabled) {
                    handMarker.setAttribute('visible', 'false');
                    handMoleculeEntity.setAttribute('visible', 'false');
                    handTextContainer.setAttribute('visible', 'false');
                  }
                }
              } else {
                // No hand detected
                handVisible = false;
                handLostTime = Date.now();
                
                // If smoothing is disabled, hide immediately
                if (!smoothingEnabled) {
                  handMarker.setAttribute('visible', 'false');
                  handMoleculeEntity.setAttribute('visible', 'false');
                  handTextContainer.setAttribute('visible', 'false');
                }
              }
              
              // Apply hand persistence only if smoothing is enabled
              if (smoothingEnabled && !handVisible && Date.now() - handLostTime > HAND_PERSISTENCE_TIME) {
                handMarker.setAttribute('visible', 'false');
                handMoleculeEntity.setAttribute('visible', 'false');
                handTextContainer.setAttribute('visible', 'false');
              }
              
              // Continue detection
              requestAnimationFrame(runDetection);
            });
          };
          
          // Wait for video to start playing
          if (arVideo.readyState === 4) {
            runDetection();
          } else {
            arVideo.addEventListener('loadeddata', runDetection);
          }
        }).catch(err => {
          console.error("Error loading hand tracking model:", err);
        });
      };
      
      // Start hand tracking after a short delay to let AR.js initialize
      setTimeout(setupHandTracking, 2000);
    };
    
    // Wait for A-Frame to be ready
    if (window.AFRAME) {
      setupAR();
    } else {
      aframeScript.onload = () => {
        arjsScript.onload = () => {
          handTrackingScript.onload = setupAR;
        };
      };
    }
    
    // Cleanup function
    return () => {
      document.body.classList.remove('ar-mode');
      
      // Stop hand tracking if active
      if (window.handTrackingModel) {
        window.handTrackingModel.dispose();
        window.handTrackingModel = null;
      }
      
      // Remove AR container if it exists
      const arContainerElement = document.querySelector('body > div[style*="position: fixed"][style*="z-index: 9999"]');
      if (arContainerElement) {
        document.body.removeChild(arContainerElement);
      }
      
      // Remove exit button if it exists
      const exitButton = document.querySelector('body > button[style*="position: fixed"]');
      if (exitButton) {
        document.body.removeChild(exitButton);
      }
      
      // Remove smoothing toggle if it exists
      const smoothingToggle = document.querySelector('body > div[style*="position: fixed"][style*="top: 20px"][style*="left: 20px"]');
      if (smoothingToggle) {
        document.body.removeChild(smoothingToggle);
      }
    };
  }, [moleculeData, enabled, onExitAR, colorScheme, moleculeName]);
  
  return <div ref={containerRef} style={{ display: 'none' }} />;
};

export default ARScene;