// src/components/MoleculeInfoPanel.js
import React, { useState, useEffect } from 'react';
import { fetchMoleculeInfo } from '../services/pubchemInfoService';
import '../styles/MoleculeInfoPanel.css';

const MoleculeInfoPanel = ({ moleculeName, cid }) => {
  const [info, setInfo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [expanded, setExpanded] = useState(true);

  useEffect(() => {
    if (!cid) return;
    
    const fetchInfo = async () => {
      setLoading(true);
      setError(null);
      try {
        const data = await fetchMoleculeInfo(cid);
        setInfo(data);
      } catch (err) {
        setError('Failed to load molecule information');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchInfo();
  }, [cid]);

  const toggleExpanded = () => setExpanded(!expanded);

  if (loading) return <div className="molecule-info-panel loading">Loading molecule data...</div>;
  if (error) return <div className="molecule-info-panel error">{error}</div>;
  if (!info) return null;

  return (
    <div className={`molecule-info-panel ${expanded ? 'expanded' : 'collapsed'}`}>
      <div className="info-header" onClick={toggleExpanded}>
        <h3>Molecule Information</h3>
        <button className="toggle-button">{expanded ? '−' : '+'}</button>
      </div>
      
      {expanded && (
        <div className="info-content">
          <table>
            <tbody>
              <tr>
                <th>Name:</th>
                <td>{moleculeName}</td>
              </tr>
              <tr>
                <th>PubChem CID:</th>
                <td>
                  <a href={`https://pubchem.ncbi.nlm.nih.gov/compound/${info.cid}`} target="_blank" rel="noopener noreferrer">
                    {info.cid}
                  </a>
                </td>
              </tr>
              <tr>
                <th>Formula:</th>
                <td>{info.formula}</td>
              </tr>
              <tr>
                <th>Molecular Weight:</th>
                <td>{info.weight} g/mol</td>
              </tr>
              <tr>
                <th>IUPAC Name:</th>
                <td className="truncate-text">{info.iupacName || 'Not available'}</td>
              </tr>
              {info.commonNames && info.commonNames.length > 0 && (
                <tr>
                  <th>Common Names:</th>
                  <td>{info.commonNames.join(', ')}</td>
                </tr>
              )}
              <tr>
                <th>XLogP:</th>
                <td>{info.logP || 'Not available'}</td>
              </tr>
              <tr>
                <th>SMILES:</th>
                <td className="truncate-text">{info.smiles || 'Not available'}</td>
              </tr>
            </tbody>
          </table>
          
          <div className="pubchem-link">
            <a 
              href={`https://pubchem.ncbi.nlm.nih.gov/compound/${info.cid}`} 
              target="_blank" 
              rel="noopener noreferrer"
            >
              View in PubChem
            </a>
          </div>
        </div>
      )}
    </div>
  );
};

export default MoleculeInfoPanel;