import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import FileUpload from './FileUpload';
import MoleculeViewer from './MoleculeViewer';
import ARScene from './ARScene';
import AIExplanation from './AIExplanation';
import TechStackPanel from './TechStackPanel';
import InfoPanel from './InfoPanel';
import MoleculeInfoPanel from './MoleculeInfoPanel';
import ColorSchemeSelector from './ColorSchemeSelector';
import { parseMoleculeFile } from '../services/moleculeParser';
import { fetchMoleculeByName, fetchMoleculeByCID } from '../services/pubchemService';
import '../styles/main.css';

const App = () => {
  const [moleculeData, setMoleculeData] = useState(null);
  const [moleculeName, setMoleculeName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [viewMode, setViewMode] = useState('3D');
  const [showSidebar, setShowSidebar] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [colorScheme, setColorScheme] = useState('cpk');
  const [moleculeCID, setMoleculeCID] = useState(null);
  const location = useLocation();

  const handleExitAR = () => {
    document.body.classList.remove('ar-mode');
    window.location.reload();
  };
  
  useEffect(() => {
    if (viewMode === 'AR') {
      document.body.classList.add('ar-mode');
    } else {
      document.body.classList.remove('ar-mode');
    }
  }, [viewMode]);
  
  const handleFileUploaded = (content, format, name, cid = null) => {
    console.log('📦 Raw molecular file content (first 300 chars):', content.slice(0, 300));
    setIsLoading(true);
    try {
      const data = parseMoleculeFile(content, format);
      console.log('🧪 Parsed molecule data:', data);
      setMoleculeData(data);
      setMoleculeName(name);
      setMoleculeCID(cid); // Set the CID for the info panel
    } catch (error) {
      console.error('❌ Error parsing molecule file:', error);
      alert('Failed to parse the molecular file. Please try another file.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearchSubmit = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    
    setIsLoading(true);
    try {
      let result;
      // Check if the query is a CID (numeric)
      if (/^\d+$/.test(searchQuery.trim())) {
        result = await fetchMoleculeByCID(searchQuery.trim());
      } else {
        result = await fetchMoleculeByName(searchQuery.trim());
      }
      
      handleFileUploaded(result.content, result.format, result.name, result.cid);
    } catch (error) {
      console.error('Failed to fetch molecule:', error);
      alert(`Failed to find molecule: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const compound = params.get('compound');
    const cid = params.get('cid');
    
    if (compound || cid) {
      setIsLoading(true);
      
      const fetchData = async () => {
        try {
          let result;
          if (cid) {
            result = await fetchMoleculeByCID(cid);
          } else {
            result = await fetchMoleculeByName(compound);
          }
          
          handleFileUploaded(result.content, result.format, result.name, result.cid);
        } catch (error) {
          console.error('❌ Error loading compound from PubChem:', error);
          alert(`Failed to load molecule: ${error.message}`);
          setIsLoading(false);
        }
      };
      
      fetchData();
    }
  }, [location.search]);

  useEffect(() => {
    const body = document.body;

    if (viewMode === 'AR') {
      body.classList.add('ar-mode');
    } else {
      body.classList.remove('ar-mode');
      window.scrollTo(0, 0);
      setTimeout(() => {
        window.dispatchEvent(new Event('resize'));
      }, 100);
    }
  }, [viewMode]);

  const toggleSidebar = () => {
    setShowSidebar(!showSidebar);
    // Prevent scrolling when sidebar is open
    if (!showSidebar) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  };

  return (
    <div className="app-container">
      <button className="info-button" onClick={toggleSidebar}>
        i
      </button>
      
      <div className={`sidebar ${showSidebar ? 'open' : ''}`}>
        <button className="sidebar-close" onClick={toggleSidebar}>✕</button>
        <InfoPanel />
      </div>

      <div className="main-content">
        <header>
          <h1>⚛️ MoleScope AR</h1>
          <p>Search, upload, and visualize molecular structures in 3D and AR</p>
          
          <div className="cloud-badge">
            <img src="https://lh3.googleusercontent.com/COxitqgJr1sJnIDe8-jiKhxDx1FrYbtRHKJ9z_hELisAlapwE9LUPh6fcXIfb5vwpbMl4xl9H9TRFPc5NOO8Sb3VSgIBrfRYvW6cUA" alt="Google Cloud" width="20" />
            <span>Powered by Google Cloud</span>
          </div>
        </header>

        <main>
          <div className="upload-section">
            {/* PubChem search form */}
            <div className="pubchem-search">
              <h3>Search PubChem</h3>
              <form onSubmit={handleSearchSubmit}>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Enter compound name or CID..."
                  className="pubchem-search-input"
                />
                <button type="submit" className="pubchem-search-button" disabled={isLoading}>
                  {isLoading ? 'Searching...' : 'Search'}
                </button>
              </form>
              <p className="search-hint">Example searches: "aspirin", "caffeine", "2244" (CID)</p>
            </div>
            
            <div className="separator">
              <span>OR</span>
            </div>
            
            <FileUpload onFileUploaded={handleFileUploaded} />
          </div>

          {moleculeData && (
            <div className="viewer-section">
              <div className="view-controls">
                <button 
                  className={viewMode === '3D' ? 'active' : ''} 
                  onClick={() => setViewMode('3D')}
                >
                  3D View
                </button>
                <button 
                  className={viewMode === 'AR' ? 'active' : ''} 
                  onClick={() => setViewMode('AR')}
                >
                  AR View
                </button>
                
                <ColorSchemeSelector
                  currentScheme={colorScheme}
                  onSchemeChange={setColorScheme}
                />
              </div>

              <div className="viewer-wrapper">
                <div className="viewer-container">
                  {viewMode === '3D' ? (
                    <MoleculeViewer 
                      moleculeData={moleculeData} 
                      colorScheme={colorScheme}
                    />
                  ) : (
                    <ARScene 
                      moleculeData={moleculeData} 
                      enabled={viewMode === 'AR'} 
                      onExitAR={handleExitAR}
                      colorScheme={colorScheme}
                      moleculeName={moleculeName}
                    />
                  )}
                </div>
              </div>

              <div className="molecule-info-wrapper">
                <div className="molecule-info">
                <h2>{moleculeName.charAt(0).toUpperCase() + moleculeName.slice(1)}</h2>
                  {moleculeCID && (
                    <MoleculeInfoPanel 
                      moleculeName={moleculeName}
                      cid={moleculeCID}
                    />
                  )}
                  <AIExplanation 
                    moleculeName={moleculeName} 
                    moleculeData={moleculeData} 
                    isLoading={isLoading} 
                  />
                </div>
              </div>
            </div>
          )}
        </main>

        <TechStackPanel />
      </div>
    </div>
  );
};

export default App;