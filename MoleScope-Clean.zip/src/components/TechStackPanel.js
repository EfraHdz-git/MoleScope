// src/components/TechStackPanel.js
import React from 'react';

const TechStackPanel = () => {
  return (
    <div className="container mb-5">
      <div className="tech-stack-panel">
        <button className="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#techStackContent" aria-expanded="false" aria-controls="techStackContent">
          <i className="bi bi-code-square me-1"></i>
          Tech Stack
        </button>

        <div className="collapse mt-2" id="techStackContent">
          <div className="card card-body tech-stack-card">
            <h5 className="text-center mb-3">Current PoC Implementation</h5>
            <div className="row">
              <div className="col-md-4">
                <h6 className="tech-category">Frontend</h6>
                <ul className="tech-list">
                  <li><span className="tech-badge react">React</span> UI framework</li>
                  <li><span className="tech-badge js">JavaScript</span> Core logic</li>
                  <li><span className="tech-badge css">CSS</span> Styling & layout</li>
                </ul>
              </div>
              <div className="col-md-4">
                <h6 className="tech-category">3D & AR</h6>
                <ul className="tech-list">
                  <li><span className="tech-badge threejs">Three.js</span> 3D molecule rendering</li>
                  <li><span className="tech-badge aframe">A-Frame</span> WebXR integration</li>
                  <li><span className="tech-badge arjs">AR.js</span> Marker-based AR</li>
                </ul>
              </div>
              <div className="col-md-4">
              <h6 className="tech-category">Data & AI</h6>
<ul className="tech-list">
  <li><span className="tech-badge molparser">Mol Parser</span> .mol / .pdb support</li>
  <li><span className="tech-badge huggingface">Hugging Face</span> Primary molecule explanation</li>
  <li><span className="tech-badge openai">OpenAI</span> Fallback for reliability</li>
  <li><span className="tech-badge axios">Axios</span> RESTful integration</li>
</ul>

              </div>
            </div>

            <hr className="my-3" />

            <h5 className="text-center mb-3">Production Version Enhancements</h5>
            <div className="row">
              <div className="col-md-4">
                <h6 className="tech-category">Advanced Computation</h6>
                <ul className="tech-list">
                  <li><span className="tech-badge quantum">Quantum</span> Drug-likeness simulation</li>
                  <li><span className="tech-badge gpu">GPU Compute</span> Real-time chemistry</li>
                  <li><span className="tech-badge ml">ML Models</span> Toxicity & interaction prediction</li>
                </ul>
              </div>
              <div className="col-md-4">
                <h6 className="tech-category">Extended Reality</h6>
                <ul className="tech-list">
                  <li><span className="tech-badge webxr">WebXR</span> Mixed reality support</li>
                  <li><span className="tech-badge ml">VR</span> Immersive visualization</li>
                  <li><span className="tech-badge gpu">Haptics</span> Tactile interaction</li>
                </ul>
              </div>
              <div className="col-md-4">
                <h6 className="tech-category">Integration & Cloud</h6>
                <ul className="tech-list">
                  <li><span className="tech-badge quantum">PubChem API</span> External compound data</li>
                  <li><span className="tech-badge cloud">Cloud</span> Scalability & sync</li>
                  <li><span className="tech-badge blockchain">Blockchain</span> Data integrity & traceability</li>
                </ul>
              </div>
            </div>

            <div className="mt-3 text-center small text-muted">
              <p className="mb-0">MoleScope AR transforms standard molecule files into immersive 3D and AR visualizations.</p>
              <p className="mb-0">Built as a technical proof of concept to bridge chemistry and spatial computing.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TechStackPanel;
