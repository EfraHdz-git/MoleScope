import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer';
import { getAtomColor, availableColorSchemes } from '../utils/colorMap';
import '../styles/MoleculeViewer.css';

const MoleculeViewer = ({ moleculeData, colorScheme = 'cpk' }) => {
  const mountRef = useRef(null);
  const containerRef = useRef(null);
  const [renderer, setRenderer] = useState(null);
  const [labelRenderer, setLabelRenderer] = useState(null);
  const [controls, setControls] = useState(null);
  const [scene, setScene] = useState(null);
  const [showLabels, setShowLabels] = useState(false);
  const [showLegend, setShowLegend] = useState(true);
  const [atomLabels, setAtomLabels] = useState([]);
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  // Toggle fullscreen
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    
    // Check if running on mobile
    const isMobile = window.innerWidth <= 768;
    
    if (isMobile) {
      // Optional: Show a message that fullscreen isn't available
      console.log("Fullscreen not supported on mobile");
      return;
    }
    
    if (!document.fullscreenElement) {
      if (containerRef.current.requestFullscreen) {
        containerRef.current.requestFullscreen();
      } else if (containerRef.current.webkitRequestFullscreen) { /* Safari */
        containerRef.current.webkitRequestFullscreen();
      } else if (containerRef.current.msRequestFullscreen) { /* IE11 */
        containerRef.current.msRequestFullscreen();
      }
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.webkitExitFullscreen) { /* Safari */
        document.webkitExitFullscreen();
      } else if (document.msExitFullscreen) { /* IE11 */
        document.msExitFullscreen();
      }
      setIsFullscreen(false);
    }
  };
  
  // Listen for fullscreen change events
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);
    document.addEventListener('MSFullscreenChange', handleFullscreenChange);
    
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullscreenChange);
      document.removeEventListener('MSFullscreenChange', handleFullscreenChange);
    };
  }, []);
  
  useEffect(() => {
    if (!moleculeData || !moleculeData.atoms || !moleculeData.bonds || !mountRef.current) return;
    
    // Initialize Three.js
    const width = mountRef.current.clientWidth;
    const height = mountRef.current.clientHeight;
    
    // Create scene
    const newScene = new THREE.Scene();
    newScene.background = new THREE.Color(0xf0f0f0);
    setScene(newScene);
    
    // Create camera
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    camera.position.z = 15;
    
    // Create renderer
    const newRenderer = new THREE.WebGLRenderer({ antialias: true });
    newRenderer.setSize(width, height);
    setRenderer(newRenderer);
    
    // Create label renderer
    const newLabelRenderer = new CSS2DRenderer();
    newLabelRenderer.setSize(width, height);
    newLabelRenderer.domElement.style.position = 'absolute';
    newLabelRenderer.domElement.style.top = '0px';
    newLabelRenderer.domElement.style.pointerEvents = 'none';
    
    // Safely append renderers to DOM
    mountRef.current.innerHTML = '';
    mountRef.current.appendChild(newRenderer.domElement);
    mountRef.current.appendChild(newLabelRenderer.domElement);
    setLabelRenderer(newLabelRenderer);
    
    // Add lighting
    const ambientLight = new THREE.AmbientLight(0x404040);
    newScene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
    directionalLight.position.set(0, 1, 1);
    newScene.add(directionalLight);
    
    // Add controls
    const newControls = new OrbitControls(camera, newRenderer.domElement);
    newControls.enableDamping = true;
    newControls.dampingFactor = 0.25;
    setControls(newControls);
    
    // Create molecule geometry
    const moleculeGroup = new THREE.Group();
    const newAtomLabels = [];
    
    // Add atoms
    moleculeData.atoms.forEach((atom) => {
      if (!atom || !atom.position) {
        console.warn('Invalid atom data:', atom);
        return;
      }
      
      const geometry = new THREE.SphereGeometry(atom.radius || 0.5, 32, 32);
      const material = new THREE.MeshPhongMaterial({ 
        color: getAtomColor(atom.element, colorScheme),
        shininess: 100 
      });
      const sphere = new THREE.Mesh(geometry, material);
      sphere.position.copy(atom.position);
      moleculeGroup.add(sphere);
      
      // Create label for atom
      const labelDiv = document.createElement('div');
      labelDiv.className = 'atom-label';
      labelDiv.textContent = atom.element;
      labelDiv.style.color = '#FFFFFF';
      labelDiv.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
      labelDiv.style.padding = '2px 5px';
      labelDiv.style.borderRadius = '3px';
      labelDiv.style.fontSize = '12px';
      
      const atomLabel = new CSS2DObject(labelDiv);
      atomLabel.position.copy(atom.position);
      atomLabel.visible = showLabels;
      moleculeGroup.add(atomLabel);
      newAtomLabels.push(atomLabel);
    });
    
    setAtomLabels(newAtomLabels);
    
    // Add bonds
    moleculeData.bonds.forEach((bond) => {
      const startAtom = moleculeData.atoms[bond.start];
      const endAtom = moleculeData.atoms[bond.end];
      
      if (!startAtom || !endAtom || !startAtom.position || !endAtom.position) {
        console.warn('Invalid bond data:', bond);
        return;
      }
      
      const start = startAtom.position;
      const end = endAtom.position;
      
      const direction = new THREE.Vector3().subVectors(end, start);
      const length = direction.length();
      
      // Create a cylinder
      const geometry = new THREE.CylinderGeometry(0.2, 0.2, length, 16);
      const material = new THREE.MeshPhongMaterial({ color: 0xcccccc });
      const cylinder = new THREE.Mesh(geometry, material);
      
      // Position and rotate the cylinder
      cylinder.position.copy(start);
      cylinder.position.addScaledVector(direction, 0.5);
      cylinder.quaternion.setFromUnitVectors(
        new THREE.Vector3(0, 1, 0),
        direction.clone().normalize()
      );
      
      moleculeGroup.add(cylinder);
    });
    
    // Center the molecule
    const boundingBox = new THREE.Box3().setFromObject(moleculeGroup);
    const center = boundingBox.getCenter(new THREE.Vector3());
    moleculeGroup.position.sub(center);
    
    newScene.add(moleculeGroup);
    
    // Animation loop with requestAnimationFrame
    let animationFrameId;
    
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      if (newControls) newControls.update();
      if (newRenderer) newRenderer.render(newScene, camera);
      if (newLabelRenderer) newLabelRenderer.render(newScene, camera);
    };
    
    animate();
    
    // Handle window resize
    const handleResize = () => {
      if (!mountRef.current || !camera || !newRenderer || !newLabelRenderer) return;
      
      const width = mountRef.current.clientWidth;
      const height = mountRef.current.clientHeight;
      
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      newRenderer.setSize(width, height);
      newLabelRenderer.setSize(width, height);
    };
    
    window.addEventListener('resize', handleResize);
    
    // Cleanup function
    return () => {
      window.removeEventListener('resize', handleResize);
      
      // Cancel animation frame
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
      
      // Clean up Three.js resources
      if (newScene) {
        newScene.clear();
      }
      
      // Safely remove renderers from DOM
      if (mountRef.current) {
        if (newRenderer && mountRef.current.contains(newRenderer.domElement)) {
          try {
            mountRef.current.removeChild(newRenderer.domElement);
          } catch (error) {
            console.warn("Error removing renderer:", error);
          }
        }
        
        if (newLabelRenderer && mountRef.current.contains(newLabelRenderer.domElement)) {
          try {
            mountRef.current.removeChild(newLabelRenderer.domElement);
          } catch (error) {
            console.warn("Error removing label renderer:", error);
          }
        }
        
        // Fallback: clear the container
        mountRef.current.innerHTML = '';
      }
      
      // Dispose of Three.js objects
      if (newRenderer) {
        newRenderer.dispose();
      }
    };
  }, [moleculeData, colorScheme]);
  
  // Update labels visibility when showLabels state changes
  useEffect(() => {
    if (atomLabels.length > 0) {
      atomLabels.forEach(label => {
        label.visible = showLabels;
      });
    }
  }, [showLabels, atomLabels]);
  
  // Toggle labels function
  const toggleLabels = () => {
    setShowLabels(!showLabels);
  };
  
  // Toggle legend function
  const toggleLegend = () => {
    setShowLegend(!showLegend);
  };
  
  // Generate color legend component
  const ColorLegend = () => {
    if (!moleculeData || !moleculeData.atoms || !showLegend) return null;
    
    // Get unique elements
    const uniqueElements = [...new Set(moleculeData.atoms.map(atom => atom.element))];
    
    // Get color scheme name
    const colorSchemeName = availableColorSchemes.find(scheme => scheme.id === colorScheme)?.name || 'CPK (Classic)';
    
    return (
      <div className="molecule-color-legend" style={{
        position: 'absolute',
        bottom: '10px',
        right: '10px',
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        padding: '10px',
        borderRadius: '4px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
        maxWidth: '180px',
        fontSize: '12px'
      }}>
        <h4 style={{ margin: '0 0 8px 0', fontSize: '14px' }}>{colorSchemeName}</h4>
        <div>
          {uniqueElements.map(element => {
            return (
              <div key={element} style={{ display: 'flex', alignItems: 'center', marginBottom: '4px' }}>
                <div style={{ 
                  width: '14px', 
                  height: '14px', 
                  backgroundColor: `#${getAtomColor(element, colorScheme).toString(16).padStart(6, '0')}`,
                  marginRight: '6px',
                  border: '1px solid #ccc',
                  borderRadius: '2px'
                }}></div>
                <span>{element}</span>
              </div>
            );
          })}
        </div>
      </div>
    );
  };
  
  return (
    <div className="molecule-viewer-container" ref={containerRef} style={{ position: 'relative', width: '100%', height: '100%' }}>
      <div className="molecule-viewer" ref={mountRef} style={{ width: '100%', height: '100%' }} />
      
      <div className="molecule-viewer-controls" style={{ 
        position: 'absolute', 
        bottom: '10px', 
        left: '10px',
        display: 'flex',
        gap: '8px'
      }}>
        <button 
          onClick={toggleLabels} 
          className="btn"
          style={{ 
            backgroundColor: showLabels ? '#3498db' : '#f0f0f0',
            color: showLabels ? 'white' : 'black',
            border: 'none',
            padding: '6px 12px',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          {showLabels ? 'Hide Labels' : 'Show Labels'}
        </button>
        
        <button 
          onClick={toggleLegend} 
          className="btn"
          style={{ 
            backgroundColor: showLegend ? '#3498db' : '#f0f0f0',
            color: showLegend ? 'white' : 'black',
            border: 'none',
            padding: '6px 12px',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          {showLegend ? 'Hide Legend' : 'Show Legend'}
        </button>
        
        <button 
          onClick={toggleFullscreen} 
          className="btn"
          style={{ 
            backgroundColor: isFullscreen ? '#e74c3c' : '#2ecc71',
            color: 'white',
            border: 'none',
            padding: '6px 12px',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          {isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
        </button>
      </div>
      
      <ColorLegend />
    </div>
  );
};

export default MoleculeViewer;