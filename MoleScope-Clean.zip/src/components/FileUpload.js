import React, { useState } from 'react';
import { getFileFormat } from '../services/moleculeParser';

const FileUpload = ({ onFileUploaded }) => {
  const [dragActive, setDragActive] = useState(false);
  const [fileName, setFileName] = useState('');
  
  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };
  
  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };
  
  const handleChange = (e) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };
  
  const handleFile = (file) => {
    const reader = new FileReader();
    const format = getFileFormat(file.name);
    
    if (format !== 'mol' && format !== 'pdb') {
      alert('Please upload a .mol or .pdb file');
      return;
    }
    
    setFileName(file.name);
    
    reader.onload = (event) => {
      const content = event.target.result;
      onFileUploaded(content, format, file.name.split('.')[0]);
    };
    
    reader.readAsText(file);
  };
  
  return (
    <div className="file-upload-container">
      <div 
        className={`upload-area ${dragActive ? 'active' : ''}`}
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
      >
        <input 
          type="file" 
          id="file-upload" 
          accept=".mol,.pdb,.sdf" 
          onChange={handleChange}
          className="input-file"
        />
        <label htmlFor="file-upload" className="file-label">
          <div className="upload-icon">
            <i className="fas fa-cloud-upload-alt"></i>
          </div>
          <div className="upload-text">
            <p>Drag & drop your molecule file here</p>
            <p>or click to browse</p>
            <p className="file-types">Supported formats: .mol, .pdb</p>
          </div>
        </label>
      </div>
      
      {fileName && (
        <div className="file-info">
          <p>Uploaded: {fileName}</p>
        </div>
      )}
      
      <div className="sample-files">
        <p>Or try our sample molecules:</p>
        <div className="sample-buttons">
        <button onClick={() => fetch('/sample-molecules/caffeine.mol')
  .then(r => r.text())
  .then(content => {
    console.log("Loading caffeine molecule");
    // Log some of the content to verify it's loading properly
    console.log(content.substring(0, 100));
    onFileUploaded(content, 'mol', 'Caffeine');
  })
  .catch(err => {
    console.error("Error loading sample molecule:", err);
    alert("Failed to load sample molecule");
  })}>
  Caffeine
</button>
          <button onClick={() => fetch('/sample-molecules/dna.pdb')
            .then(r => r.text())
            .then(content => onFileUploaded(content, 'pdb', 'DNA Fragment'))}>
            DNA Fragment
          </button>
          <button onClick={() => fetch('/sample-molecules/protein.pdb')
            .then(r => r.text())
            .then(content => onFileUploaded(content, 'pdb', 'Protein'))}>
            Protein
          </button>
        </div>
      </div>
    </div>
  );
};

export default FileUpload;